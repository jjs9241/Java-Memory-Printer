package javastory.club.stage3.util;

public class StringUtil {
	public static boolean isEmpty(String str) {
		return str == null || str.length()==0;
	}
}
