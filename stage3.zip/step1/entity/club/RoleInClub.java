package javastory.club.stage3.step1.entity.club;

public enum RoleInClub {
	//
	Member, 
	President
}