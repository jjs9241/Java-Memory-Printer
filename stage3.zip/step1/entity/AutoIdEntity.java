package javastory.club.stage3.step1.entity;

public interface AutoIdEntity {
	//
	public String getId(); 
	public String getIdFormat(); 
	public void setAutoId(String autoId); 
}