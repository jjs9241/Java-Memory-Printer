package javastory.club.stage3.step4.store;

public interface IOStore {

    public void saveToText();
    public void saveToSimpleText();
    public void loadTextfile();
}
