package javastory.club.stage3.step4.service;

public interface IOService {
    //
    public void saveToText();
    public void loadSaveTextfile();
}
