package javastory.club.stage3.step4.util;

public class ClubDuplicationException extends RuntimeException {
	//
	private static final long serialVersionUID = -4246979292397269539L;

	public ClubDuplicationException(String message) {
		super(message); 
	}
}