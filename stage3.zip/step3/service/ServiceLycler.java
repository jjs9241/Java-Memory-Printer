package javastory.club.stage3.step3.service;

public interface ServiceLycler {
	//
	public BoardService createBoardService(); 
	public ClubService createClubService(); 
	public MemberService createMemberService(); 
	public PostingService createPostingService(); 
}